package com.example.lonelytwitter;

public class Sad extends Mood{
    @Override
    public String getMood() {
        return "sad";
    }
}
