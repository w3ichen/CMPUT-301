package com.example.lonelytwitter;

public class Happy extends Mood{
    @Override
    public String getMood() {
        return "happy";
    }
}
