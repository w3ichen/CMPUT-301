class Artist extends Employee {

}