class Employee {
    private String name;
    public String getName() {
        return name;
    }
}