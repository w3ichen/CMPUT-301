class Manager extends Employee {

}